<?php
/**
 * Create a Feed
 *
 * @package tailwindhelper
 * @subpackage processors
 */

use TreehillStudio\TailwindHelper\Processors\Processor;

class TailwindHelperScanClassesProcessor extends Processor
{
    public $languageTopics = ['core:default', 'tailwindhelper:default'];

    /**
     * {@inheritDoc}
     * @return array|mixed|string
     */
    function process()
    {
        $classes = [];

        /** @var \modChunk[] $chunks */
        $chunks = $this->modx->getIterator('modChunk');
        foreach ($chunks as $chunk) {
            $chunkContent = $chunk->get('content');

            $classes = array_merge($classes, $this->tailwindhelper->getDefaultClasses($chunkContent));
            $classes = array_merge($classes, $this->tailwindhelper->getAlpineClasses($chunkContent));
        }

        sort($classes);

        /** @var \modTemplate[] $templates */
        $templates = $this->modx->getIterator('modTemplate');
        foreach ($templates as $template) {
            $templateContent = $template->get('content');

            $classes = array_merge($classes, $this->tailwindhelper->getDefaultClasses($templateContent));
            $classes = array_merge($classes, $this->tailwindhelper->getAlpineClasses($templateContent));
        }

        sort($classes);

        /** @var \modResource[] $resources */
        $resources = $this->modx->getIterator('modResource');
        foreach ($resources as $resource) {
            $resourceContent = $resource->get('content');

            $classes = array_merge($classes, $this->tailwindhelper->getDefaultClasses($resourceContent));
            $classes = array_merge($classes, $this->tailwindhelper->getAlpineClasses($resourceContent));
        }

        /** @var \modTemplateVarResource[] $templateVars */
        $templateVars = $this->modx->getIterator('modTemplateVarResource');
        foreach ($templateVars as $templateVar) {
            $templateVarContent = $templateVar->get('value');

            $classes = array_merge($classes, $this->tailwindhelper->getDefaultClasses($templateVarContent));
            $classes = array_merge($classes, $this->tailwindhelper->getAlpineClasses($templateVarContent));
        }

        $classes = array_unique(array_filter($classes));
        sort($classes);
        $path = $this->tailwindhelper->getOption('safelistFolder');
        if (!file_exists($path)) {
            if (!$this->modx->cacheManager->writeTree($path)) {
                $message = 'Could not create "' . $path . '"';
                return $this->failure($message);
            }
        }
        $this->modx->cacheManager->writeFile($path . 'safelist.json', json_encode($classes, JSON_PRETTY_PRINT));

        return $this->success(json_encode($classes, JSON_PRETTY_PRINT));
    }
}

return 'TailwindHelperScanClassesProcessor';
