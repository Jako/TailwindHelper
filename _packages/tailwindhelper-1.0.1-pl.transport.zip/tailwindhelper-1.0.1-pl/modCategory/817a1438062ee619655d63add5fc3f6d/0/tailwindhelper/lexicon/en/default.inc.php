<?php
/**
 * Default Lexicon Entries for TailwindHelper
 *
 * @package tailwindhelper
 * @subpackage lexicon
 */
$_lang['tailwindhelper'] = 'TailwindHelper';

$_lang['tailwindhelper.menu'] = 'TailwindHelper';
$_lang['tailwindhelper.menu_desc'] = 'Update Tailwind Safelist';
