# TailwindHelper

MODX Helper for Tailwind

- Author: Thomas Jakobi <thomas.jakobi@partout.info>
- License: GNU GPLv2

## Features

- Write a safelist.json on base on chunk, template and resource content

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/TailwindHelper/

## GitHub Repository

https://github.com/Jako/TailwindHelper
